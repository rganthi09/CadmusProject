import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDao implements IUserDao {
	public boolean checkLogin(String name, String pass){
		boolean status = false;
		Connection con = null;
		try{
			try{
				Class.forName("com.mysql.jdbc.Driver");
			}catch(ClassNotFoundException ce){
				ce.printStackTrace();
			}
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "system");
			String query = "select name, pass from login where name=?";
			PreparedStatement ps = 	con.prepareStatement(query);
			ps.setString(1, name);
			ps.setString(2, pass);
			ResultSet rs = ps.executeQuery();
			if (rs.next()){
				if (rs.getString("name").equals(name) && rs.getString("pass").equals(pass)){
					status = true;
				}else{
					status = false;
				}
			}
		}catch(SQLException se){
			
		}finally{
			if (con!=null){
				try{
					con.close();
				}catch(SQLException se){
					se.printStackTrace();
				}
			}
		}
		return status;
	}
}
