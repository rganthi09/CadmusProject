
public interface IUserDao {
	public boolean checkLogin(String name, String pass );
		

}
